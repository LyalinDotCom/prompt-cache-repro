# Prompt cache benchmark report

Run: eaf37f12-64dc-48bb-aa69-282a798f1623 · completed · node

Created: 2026-10-18T19:18:49.454Z. Finished: 2026-10-18T19:19:42.549Z.

Scenario: agent; 8 turns per trial (turn 0 is excluded from hit rates); 1 trials; seed: theo-regime-focused-2026-10-18-gpt-6.1-sol-agent-cross-16k.

| Profile | Gap (s) | Attempts / errors | Measured followups | Strict previous-input match | Any hit | Token hit | Reusable capture | Input cost | Theoretical ideal input | Theoretical input multiplier | Theoretical followup multiplier | Output cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| GPT-6.1 Sol · OpenAI paid account | 5 | 8 / 0 | 7 | 0.0% | 100.0% | 88.3% | 98.8% | $0.048766 | $0.047011 | 1.037 | 1.059 | $0.001120 |

Full hit compares reported cached reads against previous successful input tokens with the configured token tolerance. It is a heuristic: hidden prefixes and provider rounding prevent proving exact prefix reuse. Any hit means cached reads > 0. Any-hit and token-hit metrics include all successful followups with a known cached-read counter, including perturbation and inputs below the minimum; their sample counts may differ from full-hit eligibility. Token hit is cached-read / total-input tokens on those followups. Reusable capture is cached-read / previous-input tokens (capped at 1).

The theoretical previous-input baseline is a hypothetical lower bound, not proof that ordinary input overhead was eligible for caching. Input costs use uncached input × input rate + cache reads × read rate + cache writes × write rate, per million tokens. Ideal input includes actual first-turn cost and then assumes all reusable prior input reads from cache and all new delta follows the provider write policy. Output costs are separate. Unknown counters remain unknown. Perturbation has no ideal reuse baseline.

Provider-eligible frontier metrics are available only for OpenAI/Anthropic with explicit read and write counters. Reusable = min(previous reads + writes, current reads + writes). Ordinary current input stays charged at its ordinary rate, reusable tokens at the read rate, and remaining current cache-boundary tokens at the write rate. Gemini exposes no equivalent write frontier; these metrics remain unknown. This is a boundary-aware counterfactual, not proof of provider-internal prefix identity.

| Profile | Gap (s) | Eligible measured turns | Eligible full match | Eligible capture | Boundary-aware ideal input | Boundary-aware input multiplier | Boundary-aware followup multiplier |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| GPT-6.1 Sol · OpenAI paid account | 5 | 7 | 100.0% | 100.0% | $0.048766 | 1.000 | 1.000 |

Wilson 95% intervals are descriptive turn-level intervals, not independent-sample confidence intervals: turns are clustered within trials. Compare independent trials and repeated randomized runs before drawing conclusions.

GPT-6.1 Sol · OpenAI paid account at 5s: Wilson interval 0.0%–35.4%.

Warnings:
- Sequential requests; no automatic retries. Fresh nonce per trial isolates cache prefixes.
- Costs are estimates, not verified bills. No spending cutoff is applied. Output cost is reported separately from input-cache multipliers.
- Wilson 95% interval describes turns only; turns within a trial are clustered and are not independent experimental replicates.
- Full hit is a previous-input token-count heuristic. Hidden provider prefixes, rounding, and minimum cache lengths prevent proof of exact prefix reuse.

SDK versions: @google/genai 2.30.0, openai 7.36.0, @anthropic-ai/sdk 0.135.0.

Pricing snapshots:
- GPT-6.1 Sol · OpenAI paid account: as of 2026-10-17; input 2, read 0.1, write 2.5, output 10 USD / million tokens. Source: https://developers.openai.com/api/docs/pricing; Standard, global processing; GPT-6.1 Sol writes at 1.25x input. Under 100K input only in this version..
