# Prompt cache benchmark report

Run: 7c2a85e2-b16c-4049-8ceb-43bd2112d680 · incomplete · node

Created: 2026-10-18T19:26:54.982Z. Finished: 2026-10-18T19:27:11.117Z.

Scenario: append; 8 turns per trial (turn 0 is excluded from hit rates); 2 trials; seed: theo-regime-focused-2026-10-18-gemini-4-argon-append-cross-16k.

| Profile | Gap (s) | Attempts / errors | Measured followups | Strict previous-input match | Any hit | Token hit | Reusable capture | Input cost | Theoretical ideal input | Theoretical input multiplier | Theoretical followup multiplier | Output cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Gemini Argon 4 · Gemini paid account | 5 | 4 / 2 | 0 | unknown | unknown | unknown | unknown | $0.031922 | $0.031922 | 1.000 | unknown | $0.000100 |

Full hit compares reported cached reads against previous successful input tokens with the configured token tolerance. It is a heuristic: hidden prefixes and provider rounding prevent proving exact prefix reuse. Any hit means cached reads > 0. Any-hit and token-hit metrics include all successful followups with a known cached-read counter, including perturbation and inputs below the minimum; their sample counts may differ from full-hit eligibility. Token hit is cached-read / total-input tokens on those followups. Reusable capture is cached-read / previous-input tokens (capped at 1).

The theoretical previous-input baseline is a hypothetical lower bound, not proof that ordinary input overhead was eligible for caching. Input costs use uncached input × input rate + cache reads × read rate + cache writes × write rate, per million tokens. Ideal input includes actual first-turn cost and then assumes all reusable prior input reads from cache and all new delta follows the provider write policy. Output costs are separate. Unknown counters remain unknown. Perturbation has no ideal reuse baseline.

Provider-eligible frontier metrics are available only for OpenAI/Anthropic with explicit read and write counters. Reusable = min(previous reads + writes, current reads + writes). Ordinary current input stays charged at its ordinary rate, reusable tokens at the read rate, and remaining current cache-boundary tokens at the write rate. Gemini exposes no equivalent write frontier; these metrics remain unknown. This is a boundary-aware counterfactual, not proof of provider-internal prefix identity.

| Profile | Gap (s) | Eligible measured turns | Eligible full match | Eligible capture | Boundary-aware ideal input | Boundary-aware input multiplier | Boundary-aware followup multiplier |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Gemini Argon 4 · Gemini paid account | 5 | 0 | unknown | unknown | $unknown | unknown | unknown |

Wilson 95% intervals are descriptive turn-level intervals, not independent-sample confidence intervals: turns are clustered within trials. Compare independent trials and repeated randomized runs before drawing conclusions.


Warnings:
- Sequential requests; no automatic retries. Fresh nonce per trial isolates cache prefixes.
- Costs are estimates, not verified bills. No spending cutoff is applied. Output cost is reported separately from input-cache multipliers.
- Run incomplete: a failed attempt or invalid continuation stopped a trial, or the planned attempt count was not reached. Successful input-cache measurements remain available.
- Gemini omitted cachedContentTokenCount; decoded as zero under the proto3 non-presence int32 / ProtoJSON default-zero contract. Raw usage is preserved.
- request is the Google SDK object; wireRequest contains its transformed HTTP JSON (config fields move to generationConfig/tools).
- Failed/cancelled attempts are excluded from hit and cost denominators; cost totals cover observed successful requests only.

SDK versions: @google/genai 2.30.0, openai 7.36.0, @anthropic-ai/sdk 0.135.0.

Pricing snapshots:
- Gemini Argon 4 · Gemini paid account: as of 2026-10-17; input 2, read 0.1, write 2, output 10 USD / million tokens. Source: https://ai.google.dev/gemini-api/docs/pricing; Argon Standard introductory rates through 2026-11-30; recheck before later runs..
