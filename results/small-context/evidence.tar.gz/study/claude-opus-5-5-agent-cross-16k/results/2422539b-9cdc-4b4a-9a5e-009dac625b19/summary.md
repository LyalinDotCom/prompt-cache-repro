# Prompt cache benchmark report

Run: 2422539b-9cdc-4b4a-9a5e-009dac625b19 · incomplete · node

Created: 2026-10-18T19:19:04.867Z. Finished: 2026-10-18T19:19:07.179Z.

Scenario: agent; 8 turns per trial (turn 0 is excluded from hit rates); 1 trials; seed: theo-regime-focused-2026-10-18-claude-opus-5-5-agent-cross-16k.

| Profile | Gap (s) | Attempts / errors | Measured followups | Strict previous-input match | Any hit | Token hit | Reusable capture | Input cost | Theoretical ideal input | Theoretical input multiplier | Theoretical followup multiplier | Output cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Claude Opus 5.5 · Anthropic paid account | 5 | 1 / 0 | 0 | unknown | unknown | unknown | unknown | $0.054466 | $0.054466 | 1.000 | unknown | $0.000000 |

Full hit compares reported cached reads against previous successful input tokens with the configured token tolerance. It is a heuristic: hidden prefixes and provider rounding prevent proving exact prefix reuse. Any hit means cached reads > 0. Any-hit and token-hit metrics include all successful followups with a known cached-read counter, including perturbation and inputs below the minimum; their sample counts may differ from full-hit eligibility. Token hit is cached-read / total-input tokens on those followups. Reusable capture is cached-read / previous-input tokens (capped at 1).

The theoretical previous-input baseline is a hypothetical lower bound, not proof that ordinary input overhead was eligible for caching. Input costs use uncached input × input rate + cache reads × read rate + cache writes × write rate, per million tokens. Ideal input includes actual first-turn cost and then assumes all reusable prior input reads from cache and all new delta follows the provider write policy. Output costs are separate. Unknown counters remain unknown. Perturbation has no ideal reuse baseline.

Provider-eligible frontier metrics are available only for OpenAI/Anthropic with explicit read and write counters. Reusable = min(previous reads + writes, current reads + writes). Ordinary current input stays charged at its ordinary rate, reusable tokens at the read rate, and remaining current cache-boundary tokens at the write rate. Gemini exposes no equivalent write frontier; these metrics remain unknown. This is a boundary-aware counterfactual, not proof of provider-internal prefix identity.

| Profile | Gap (s) | Eligible measured turns | Eligible full match | Eligible capture | Boundary-aware ideal input | Boundary-aware input multiplier | Boundary-aware followup multiplier |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Claude Opus 5.5 · Anthropic paid account | 5 | 0 | unknown | unknown | $0.054466 | 1.000 | unknown |

Wilson 95% intervals are descriptive turn-level intervals, not independent-sample confidence intervals: turns are clustered within trials. Compare independent trials and repeated randomized runs before drawing conclusions.


Warnings:
- Sequential requests; no automatic retries. Fresh nonce per trial isolates cache prefixes.
- Costs are estimates, not verified bills. No spending cutoff is applied. Output cost is reported separately from input-cache multipliers.
- Run incomplete: a failed attempt or invalid continuation stopped a trial, or the planned attempt count was not reached. Successful input-cache measurements remain available.
- Agent response did not contain exactly one complete read_fixture call; trial must stop without fabricated continuation.
- Provider continuation is invalid; trial stopped before the next request.

SDK versions: @google/genai 2.30.0, openai 7.36.0, @anthropic-ai/sdk 0.135.0.

Pricing snapshots:
- Claude Opus 5.5 · Anthropic paid account: as of 2026-10-17; input 4, read 0.2, write 5, output 20 USD / million tokens. Source: https://platform.claude.com/docs/en/about-claude/pricing; Opus 5.5 Standard, global processing; 5-minute automatic cache writes..
