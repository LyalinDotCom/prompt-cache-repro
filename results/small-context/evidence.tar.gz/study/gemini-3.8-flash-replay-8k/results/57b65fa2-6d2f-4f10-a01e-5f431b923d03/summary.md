# Prompt cache benchmark report

Run: 57b65fa2-6d2f-4f10-a01e-5f431b923d03 · completed · node

Created: 2026-10-18T19:21:49.122Z. Finished: 2026-10-18T19:23:29.243Z.

Scenario: replay; 8 turns per trial (turn 0 is excluded from hit rates); 2 trials; seed: theo-regime-focused-2026-10-18-gemini-3.8-flash-replay-8k.

| Profile | Gap (s) | Attempts / errors | Measured followups | Strict previous-input match | Any hit | Token hit | Reusable capture | Input cost | Theoretical ideal input | Theoretical input multiplier | Theoretical followup multiplier | Output cost |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Gemini Flash 3.8 · Gemini paid account | 5 | 16 / 0 | 14 | 0.0% | 100.0% | 74.5% | 74.5% | $0.039683 | $0.020386 | 1.947 | 3.299 | $0.000060 |

Full hit compares reported cached reads against previous successful input tokens with the configured token tolerance. It is a heuristic: hidden prefixes and provider rounding prevent proving exact prefix reuse. Any hit means cached reads > 0. Any-hit and token-hit metrics include all successful followups with a known cached-read counter, including perturbation and inputs below the minimum; their sample counts may differ from full-hit eligibility. Token hit is cached-read / total-input tokens on those followups. Reusable capture is cached-read / previous-input tokens (capped at 1).

The theoretical previous-input baseline is a hypothetical lower bound, not proof that ordinary input overhead was eligible for caching. Input costs use uncached input × input rate + cache reads × read rate + cache writes × write rate, per million tokens. Ideal input includes actual first-turn cost and then assumes all reusable prior input reads from cache and all new delta follows the provider write policy. Output costs are separate. Unknown counters remain unknown. Perturbation has no ideal reuse baseline.

Provider-eligible frontier metrics are available only for OpenAI/Anthropic with explicit read and write counters. Reusable = min(previous reads + writes, current reads + writes). Ordinary current input stays charged at its ordinary rate, reusable tokens at the read rate, and remaining current cache-boundary tokens at the write rate. Gemini exposes no equivalent write frontier; these metrics remain unknown. This is a boundary-aware counterfactual, not proof of provider-internal prefix identity.

| Profile | Gap (s) | Eligible measured turns | Eligible full match | Eligible capture | Boundary-aware ideal input | Boundary-aware input multiplier | Boundary-aware followup multiplier |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Gemini Flash 3.8 · Gemini paid account | 5 | 0 | unknown | unknown | $unknown | unknown | unknown |

Wilson 95% intervals are descriptive turn-level intervals, not independent-sample confidence intervals: turns are clustered within trials. Compare independent trials and repeated randomized runs before drawing conclusions.

Gemini Flash 3.8 · Gemini paid account at 5s: Wilson interval 0.0%–21.5%.

Warnings:
- Sequential requests; no automatic retries. Fresh nonce per trial isolates cache prefixes.
- Costs are estimates, not verified bills. No spending cutoff is applied. Output cost is reported separately from input-cache multipliers.
- Gemini omitted cachedContentTokenCount; decoded as zero under the proto3 non-presence int32 / ProtoJSON default-zero contract. Raw usage is preserved.
- request is the Google SDK object; wireRequest contains its transformed HTTP JSON (config fields move to generationConfig/tools).
- Wilson 95% interval describes turns only; turns within a trial are clustered and are not independent experimental replicates.
- Full hit is a previous-input token-count heuristic. Hidden provider prefixes, rounding, and minimum cache lengths prevent proof of exact prefix reuse.

SDK versions: @google/genai 2.30.0, openai 7.36.0, @anthropic-ai/sdk 0.135.0.

Pricing snapshots:
- Gemini Flash 3.8 · Gemini paid account: as of 2026-10-17; input 0.75, read 0.075, write 0.75, output 3.75 USD / million tokens. Source: https://ai.google.dev/gemini-api/docs/pricing; Flash 3.8 Standard introductory rates through 2026-12-31; implicit cache only in this benchmark..
