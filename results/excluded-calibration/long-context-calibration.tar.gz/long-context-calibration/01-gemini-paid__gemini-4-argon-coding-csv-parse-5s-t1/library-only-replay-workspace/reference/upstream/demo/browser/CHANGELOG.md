# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.3.4](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.3.3...csv-demo-browser@0.3.4) (2026-09-25)

**Note:** Version bump only for package csv-demo-browser





## [0.3.3](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.3.2...csv-demo-browser@0.3.3) (2026-08-05)

**Note:** Version bump only for package csv-demo-browser

## [0.3.2](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.3.1...csv-demo-browser@0.3.2) (2026-08-02)

**Note:** Version bump only for package csv-demo-browser

## [0.3.1](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.3.0...csv-demo-browser@0.3.1) (2026-07-02)

**Note:** Version bump only for package csv-demo-browser

## 0.3.0 (2026-06-14)

### Features

- **csv-demo-webpack:** split usages by packages

### Bug Fixes

- support ts node16 resolution in cjs ([#354](https://github.com/adaltas/node-csv/issues/354))

## [0.2.3](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.2.2...csv-demo-browser@0.2.3) (2026-03-20)

**Note:** Version bump only for package csv-demo-browser

## [0.2.2](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.2.1...csv-demo-browser@0.2.2) (2026-03-17)

**Note:** Version bump only for package csv-demo-browser

## [0.2.1](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.21...csv-demo-browser@0.2.1) (2025-07-16)

**Note:** Version bump only for package csv-demo-browser

## 0.2.0 (2025-07-10)

### Features

- **csv-demo-webpack:** split usages by packages ([214c759](https://github.com/adaltas/node-csv/commit/214c75980d61bf96ec1d6892858887ba29235987))

### Bug Fixes

- support ts node16 resolution in cjs ([#354](https://github.com/adaltas/node-csv/issues/354)) ([fa09d03](https://github.com/adaltas/node-csv/commit/fa09d03aaf0008b2790656871ca6b2c4be12d14c))

## [0.1.21](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.20...csv-demo-browser@0.1.21) (2024-11-21)

**Note:** Version bump only for package csv-demo-browser

## [0.1.20](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.19...csv-demo-browser@0.1.20) (2024-07-27)

**Note:** Version bump only for package csv-demo-browser

## [0.1.19](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.18...csv-demo-browser@0.1.19) (2024-05-13)

**Note:** Version bump only for package csv-demo-browser

## [0.1.18](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.17...csv-demo-browser@0.1.18) (2024-02-28)

**Note:** Version bump only for package csv-demo-browser

## [0.1.17](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.16...csv-demo-browser@0.1.17) (2024-02-27)

**Note:** Version bump only for package csv-demo-browser

## [0.1.16](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.15...csv-demo-browser@0.1.16) (2023-12-08)

**Note:** Version bump only for package csv-demo-browser

## [0.1.15](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.14...csv-demo-browser@0.1.15) (2023-10-09)

**Note:** Version bump only for package csv-demo-browser

## [0.1.14](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.13...csv-demo-browser@0.1.14) (2023-10-05)

**Note:** Version bump only for package csv-demo-browser

## [0.1.13](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.12...csv-demo-browser@0.1.13) (2023-08-25)

**Note:** Version bump only for package csv-demo-browser

## [0.1.12](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.11...csv-demo-browser@0.1.12) (2023-08-24)

**Note:** Version bump only for package csv-demo-browser

## [0.1.11](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.10...csv-demo-browser@0.1.11) (2023-05-26)

**Note:** Version bump only for package csv-demo-browser

## [0.1.10](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.9...csv-demo-browser@0.1.10) (2023-05-09)

**Note:** Version bump only for package csv-demo-browser

## [0.1.9](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.8...csv-demo-browser@0.1.9) (2023-05-04)

**Note:** Version bump only for package csv-demo-browser

## [0.1.8](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.7...csv-demo-browser@0.1.8) (2023-04-30)

**Note:** Version bump only for package csv-demo-browser

## [0.1.7](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.5...csv-demo-browser@0.1.7) (2023-04-16)

**Note:** Version bump only for package csv-demo-browser

## [0.1.6](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.5...csv-demo-browser@0.1.6) (2023-04-16)

**Note:** Version bump only for package csv-demo-browser

## [0.1.5](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.4...csv-demo-browser@0.1.5) (2023-03-03)

**Note:** Version bump only for package csv-demo-browser

## [0.1.4](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.3...csv-demo-browser@0.1.4) (2023-02-08)

### Bug Fixes

- support ts node16 resolution in cjs ([#354](https://github.com/adaltas/node-csv/issues/354)) ([fa09d03](https://github.com/adaltas/node-csv/commit/fa09d03aaf0008b2790656871ca6b2c4be12d14c))

## [0.1.3](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.2...csv-demo-browser@0.1.3) (2022-11-08)

**Note:** Version bump only for package csv-demo-browser

### [0.1.2](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.1...csv-demo-browser@0.1.2) (2022-05-24)

**Note:** Version bump only for package csv-demo-browser

## [0.1.1](https://github.com/adaltas/node-csv/compare/csv-demo-browser@0.1.0...csv-demo-browser@0.1.1) (2021-12-29)

**Note:** Version bump only for package csv-demo-browser

# 0.1.0 (2021-11-19)

### Features

- **csv-demo-webpack:** split usages by packages ([214c759](https://github.com/adaltas/node-csv/commit/214c75980d61bf96ec1d6892858887ba29235987))
