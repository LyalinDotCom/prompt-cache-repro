# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.4.4](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.4.3...csv-demo-cjs@0.4.4) (2026-09-25)

**Note:** Version bump only for package csv-demo-cjs





## [0.4.3](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.4.2...csv-demo-cjs@0.4.3) (2026-08-05)

**Note:** Version bump only for package csv-demo-cjs

## [0.4.2](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.4.1...csv-demo-cjs@0.4.2) (2026-08-02)

**Note:** Version bump only for package csv-demo-cjs

## [0.4.1](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.4.0...csv-demo-cjs@0.4.1) (2026-07-02)

### Bug Fixes

- **csv-parse:** ship stream cjs export ([#490](https://github.com/adaltas/node-csv/issues/490))

## 0.4.0 (2026-06-14)

### Features

- backward support for node 8
- **csv-demo-cjs:** new stringify.ts sample

### Bug Fixes

- **csv-demo-cjs:** ts type
- **csv-demo-ts-cjs-node16:** upgrade module definition after latest typescript
- support ts node16 resolution in cjs ([#354](https://github.com/adaltas/node-csv/issues/354))

## [0.3.3](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.3.2...csv-demo-cjs@0.3.3) (2026-03-20)

**Note:** Version bump only for package csv-demo-cjs

## [0.3.2](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.3.1...csv-demo-cjs@0.3.2) (2026-03-17)

**Note:** Version bump only for package csv-demo-cjs

## [0.3.1](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.19...csv-demo-cjs@0.3.1) (2025-07-16)

### Bug Fixes

- **csv-demo-cjs:** ts type ([9bb1bf8](https://github.com/adaltas/node-csv/commit/9bb1bf8e0084cd38f788dd56851b9af4149ac49d))

## 0.3.0 (2025-07-10)

### Features

- backward support for node 8 ([496231d](https://github.com/adaltas/node-csv/commit/496231dfd838f0a6a72269a5a2390a4c637cef95))
- **csv-demo-cjs:** new stringify.ts sample ([b44de05](https://github.com/adaltas/node-csv/commit/b44de05d70b4577cdb85c4f285321eea840f8fa3))

### Bug Fixes

- **csv-demo-cjs:** ts type ([9bb1bf8](https://github.com/adaltas/node-csv/commit/9bb1bf8e0084cd38f788dd56851b9af4149ac49d))
- **csv-demo-ts-cjs-node16:** upgrade module definition after latest typescript ([87fe919](https://github.com/adaltas/node-csv/commit/87fe91996fb2a8895c252177fca4f0cb59a518f9))
- support ts node16 resolution in cjs ([#354](https://github.com/adaltas/node-csv/issues/354)) ([fa09d03](https://github.com/adaltas/node-csv/commit/fa09d03aaf0008b2790656871ca6b2c4be12d14c))

## [0.2.19](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.18...csv-demo-cjs@0.2.19) (2024-11-21)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.18](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.17...csv-demo-cjs@0.2.18) (2024-07-27)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.17](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.16...csv-demo-cjs@0.2.17) (2024-05-13)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.16](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.15...csv-demo-cjs@0.2.16) (2024-02-28)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.15](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.14...csv-demo-cjs@0.2.15) (2024-02-27)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.14](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.13...csv-demo-cjs@0.2.14) (2023-12-08)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.13](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.12...csv-demo-cjs@0.2.13) (2023-10-09)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.12](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.11...csv-demo-cjs@0.2.12) (2023-10-05)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.11](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.10...csv-demo-cjs@0.2.11) (2023-08-25)

### Bug Fixes

- **csv-demo-ts-cjs-node16:** upgrade module definition after latest typescript ([87fe919](https://github.com/adaltas/node-csv/commit/87fe91996fb2a8895c252177fca4f0cb59a518f9))

## [0.2.10](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.9...csv-demo-cjs@0.2.10) (2023-08-24)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.9](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.8...csv-demo-cjs@0.2.9) (2023-05-26)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.8](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.7...csv-demo-cjs@0.2.8) (2023-05-09)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.7](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.6...csv-demo-cjs@0.2.7) (2023-05-04)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.6](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.5...csv-demo-cjs@0.2.6) (2023-04-30)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.5](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.3...csv-demo-cjs@0.2.5) (2023-04-16)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.4](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.3...csv-demo-cjs@0.2.4) (2023-04-16)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.3](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.2...csv-demo-cjs@0.2.3) (2023-03-03)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.2](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.1...csv-demo-cjs@0.2.2) (2023-02-08)

### Bug Fixes

- support ts node16 resolution in cjs ([#354](https://github.com/adaltas/node-csv/issues/354)) ([fa09d03](https://github.com/adaltas/node-csv/commit/fa09d03aaf0008b2790656871ca6b2c4be12d14c))

## [0.2.1](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.2.0...csv-demo-cjs@0.2.1) (2022-11-08)

**Note:** Version bump only for package csv-demo-cjs

## [0.2.0](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.1.2...csv-demo-cjs@0.2.0) (2022-07-10)

### Features

- **csv-demo-cjs:** new stringify.ts sample ([b44de05](https://github.com/adaltas/node-csv/commit/b44de05d70b4577cdb85c4f285321eea840f8fa3))

### [0.1.2](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.1.1...csv-demo-cjs@0.1.2) (2022-05-24)

**Note:** Version bump only for package csv-demo-cjs

## [0.1.1](https://github.com/adaltas/node-csv/compare/csv-demo-cjs@0.1.0...csv-demo-cjs@0.1.1) (2021-12-29)

**Note:** Version bump only for package csv-demo-cjs

# 0.1.0 (2021-11-19)

### Features

- backward support for node 8 ([496231d](https://github.com/adaltas/node-csv/commit/496231dfd838f0a6a72269a5a2390a4c637cef95))
