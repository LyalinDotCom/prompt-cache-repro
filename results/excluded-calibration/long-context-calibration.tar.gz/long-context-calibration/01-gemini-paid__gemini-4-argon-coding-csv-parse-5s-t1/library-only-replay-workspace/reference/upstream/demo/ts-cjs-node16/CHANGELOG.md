# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.2.28](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.27...csv-demo-ts-cjs-node16@0.2.28) (2026-09-25)

**Note:** Version bump only for package csv-demo-ts-cjs-node16





## [0.2.27](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.26...csv-demo-ts-cjs-node16@0.2.27) (2026-08-05)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.26](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.25...csv-demo-ts-cjs-node16@0.2.26) (2026-08-02)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.25](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.24...csv-demo-ts-cjs-node16@0.2.25) (2026-07-02)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## 0.2.24 (2026-06-14)

### Bug Fixes

- **csv-demo-ts-cjs-node16:** upgrade module definition after latest typescript
- support ts node16 resolution in cjs ([#354](https://github.com/adaltas/node-csv/issues/354))

## [0.2.23](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.22...csv-demo-ts-cjs-node16@0.2.23) (2026-03-20)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.22](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.21...csv-demo-ts-cjs-node16@0.2.22) (2026-03-17)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.21](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.19...csv-demo-ts-cjs-node16@0.2.21) (2025-07-16)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## 0.2.20 (2025-07-10)

### Bug Fixes

- **csv-demo-ts-cjs-node16:** upgrade module definition after latest typescript ([87fe919](https://github.com/adaltas/node-csv/commit/87fe91996fb2a8895c252177fca4f0cb59a518f9))
- support ts node16 resolution in cjs ([#354](https://github.com/adaltas/node-csv/issues/354)) ([fa09d03](https://github.com/adaltas/node-csv/commit/fa09d03aaf0008b2790656871ca6b2c4be12d14c))

## [0.2.19](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.18...csv-demo-ts-cjs-node16@0.2.19) (2024-11-21)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.18](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.17...csv-demo-ts-cjs-node16@0.2.18) (2024-07-27)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.17](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.16...csv-demo-ts-cjs-node16@0.2.17) (2024-05-13)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.16](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.15...csv-demo-ts-cjs-node16@0.2.16) (2024-02-28)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.15](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.14...csv-demo-ts-cjs-node16@0.2.15) (2024-02-27)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.14](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.13...csv-demo-ts-cjs-node16@0.2.14) (2023-12-08)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.13](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.12...csv-demo-ts-cjs-node16@0.2.13) (2023-10-09)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## [0.2.12](https://github.com/adaltas/node-csv/compare/csv-demo-ts-cjs-node16@0.2.11...csv-demo-ts-cjs-node16@0.2.12) (2023-10-05)

**Note:** Version bump only for package csv-demo-ts-cjs-node16

## 0.2.11 (2023-08-25)

### Bug Fixes

- **csv-demo-ts-cjs-node16:** upgrade module definition after latest typescript ([87fe919](https://github.com/adaltas/node-csv/commit/87fe91996fb2a8895c252177fca4f0cb59a518f9))
- support ts node16 resolution in cjs ([#354](https://github.com/adaltas/node-csv/issues/354)) ([fa09d03](https://github.com/adaltas/node-csv/commit/fa09d03aaf0008b2790656871ca6b2c4be12d14c))

## [0.2.10](https://github.com/adaltas/node-csv/compare/csv-demo-ts-moduleresolution-node16-cjs@0.2.9...csv-demo-ts-moduleresolution-node16-cjs@0.2.10) (2023-08-24)

**Note:** Version bump only for package csv-demo-ts-moduleresolution-node16-cjs

## [0.2.9](https://github.com/adaltas/node-csv/compare/csv-demo-ts-moduleresolution-node16-cjs@0.2.8...csv-demo-ts-moduleresolution-node16-cjs@0.2.9) (2023-05-26)

**Note:** Version bump only for package csv-demo-ts-moduleresolution-node16-cjs

## [0.2.8](https://github.com/adaltas/node-csv/compare/csv-demo-ts-moduleresolution-node16-cjs@0.2.7...csv-demo-ts-moduleresolution-node16-cjs@0.2.8) (2023-05-09)

**Note:** Version bump only for package csv-demo-ts-moduleresolution-node16-cjs

## [0.2.7](https://github.com/adaltas/node-csv/compare/csv-demo-ts-moduleresolution-node16-cjs@0.2.6...csv-demo-ts-moduleresolution-node16-cjs@0.2.7) (2023-05-04)

**Note:** Version bump only for package csv-demo-ts-moduleresolution-node16-cjs

## [0.2.6](https://github.com/adaltas/node-csv/compare/csv-demo-ts-moduleresolution-node16-cjs@0.2.5...csv-demo-ts-moduleresolution-node16-cjs@0.2.6) (2023-04-30)

**Note:** Version bump only for package csv-demo-ts-moduleresolution-node16-cjs

## [0.2.5](https://github.com/adaltas/node-csv/compare/csv-demo-ts-moduleresolution-node16-cjs@0.2.3...csv-demo-ts-moduleresolution-node16-cjs@0.2.5) (2023-04-16)

**Note:** Version bump only for package csv-demo-ts-moduleresolution-node16-cjs

## [0.2.4](https://github.com/adaltas/node-csv/compare/csv-demo-ts-moduleresolution-node16-cjs@0.2.3...csv-demo-ts-moduleresolution-node16-cjs@0.2.4) (2023-04-16)

**Note:** Version bump only for package csv-demo-ts-moduleresolution-node16-cjs

## [0.2.3](https://github.com/adaltas/node-csv/compare/csv-demo-ts-moduleresolution-node16-cjs@0.2.2...csv-demo-ts-moduleresolution-node16-cjs@0.2.3) (2023-03-03)

**Note:** Version bump only for package csv-demo-ts-moduleresolution-node16-cjs

## 0.2.2 (2023-02-08)

### Bug Fixes

- support ts node16 resolution in cjs ([#354](https://github.com/adaltas/node-csv/issues/354)) ([fa09d03](https://github.com/adaltas/node-csv/commit/fa09d03aaf0008b2790656871ca6b2c4be12d14c))
