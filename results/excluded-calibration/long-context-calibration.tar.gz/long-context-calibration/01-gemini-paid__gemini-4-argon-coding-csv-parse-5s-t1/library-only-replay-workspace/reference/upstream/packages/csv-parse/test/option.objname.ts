import should from "should";
import dedent from "dedent";
import { parse } from "../lib/index.js";
import { parse as parseSync } from "../lib/sync.js";

describe("Option `objname`", function () {
  describe("validation", function () {
    it("basic", function () {
      parse("", { objname: "sth", columns: true }, () => {});
      parse("", { objname: Buffer.from("sth"), columns: true }, () => {});
      parse("", { objname: 1 }, () => {});
      parse("", { objname: null }, () => {});
      parse("", { objname: undefined }, () => {});
      (() => {
        parse("", { objname: "" }, () => {});
      }).should.throw("Invalid Option: objname must be a non empty string");
      (() => {
        parse("", { objname: Buffer.from("") }, () => {});
      }).should.throw("Invalid Option: objname must be a non empty buffer");
    });

    it("field require columns", function () {
      (() => {
        parse("", { objname: "field" }, () => {});
      }).should.throw(
        [
          "Invalid Option:",
          "objname field must be combined with columns",
          "or be defined as an index",
        ].join(" "),
      );
    });

    it("index incompatible with columns", function () {
      (() => {
        parse("", { objname: 1, columns: true }, () => {});
      }).should.throw(
        [
          "Invalid Option:",
          "objname index cannot be combined with columns",
          "or be defined as a field",
        ].join(" "),
      );
    });
  });

  describe("map to a field", function () {
    it("dont modify prototype with streaming (see #479)", function (next) {
      interface Records {
        [key: string]: {
          key: string;
          value: string;
        };
      }
      parse<Records>(
        "key,value\n__proto__,polluted\n",
        {
          objname: "key",
          columns: true,
        },
        (err, records) => {
          if (err) return next(err);
          should(Object.getPrototypeOf(records)).be.Null();
          should((records as unknown as Records)["__proto__"]).eql({
            key: "__proto__",
            value: "polluted",
          });
          next();
        },
      );
    });

    it("dont modify prototype with async (see #479)", function () {
      interface Records {
        [key: string]: {
          key: string;
          value: string;
        };
      }
      const records = parseSync<Records>("key,value\n__proto__,polluted\n", {
        objname: "key",
        columns: true,
      });
      should(Object.getPrototypeOf(records)).be.Null();
      should((records as unknown as Records)["__proto__"]).eql({
        key: "__proto__",
        value: "polluted",
      });
    });

    it("convert a buffer to a column name", function (next) {
      parse(
        `a,b,c`,
        { objname: Buffer.from("h1"), columns: ["h1", "h2", "h3"] },
        (err, records) => {
          if (err) return next(err);
          should(records).match({
            a: {
              h1: "a",
              h2: "b",
              h3: "c",
            },
          });
          next();
        },
      );
    });

    it("should print object of objects with properties using value of given column from columns", function (next) {
      parse(
        dedent`
          a,b,c
          d,e,f
        `,
        { objname: "FIELD_1", columns: ["FIELD_1", "FIELD_2", "FIELD_3"] },
        (err, records) => {
          if (err) return next(err);
          should(records).match({
            a: {
              FIELD_1: "a",
              FIELD_2: "b",
              FIELD_3: "c",
            },
            d: {
              FIELD_1: "d",
              FIELD_2: "e",
              FIELD_3: "f",
            },
          });
          next();
        },
      );
    });

    it("should print object of objects with properties using value of given column from header record", function (next) {
      parse(
        dedent`
          FIELD_1,FIELD_2,FIELD_3
          a,b,c
          d,e,f
        `,
        { objname: "FIELD_1", columns: true },
        (err, records) => {
          if (err) return next(err);
          should(records).match({
            a: {
              FIELD_1: "a",
              FIELD_2: "b",
              FIELD_3: "c",
            },
            d: {
              FIELD_1: "d",
              FIELD_2: "e",
              FIELD_3: "f",
            },
          });
          next();
        },
      );
    });

    it("combined with info", function (next) {
      parse(
        dedent`
          FIELD_1,FIELD_2,FIELD_3
          a,b,c
          d,e,f
        `,
        { objname: "FIELD_2", columns: true, info: true },
        (err, records) => {
          if (err) return next(err);
          should(records).match({
            b: {
              record: {
                FIELD_1: "a",
                FIELD_2: "b",
                FIELD_3: "c",
              },
              info: {
                bytes: 30,
                lines: 2,
              },
            },
            e: {
              record: {
                FIELD_1: "d",
                FIELD_2: "e",
                FIELD_3: "f",
              },
              info: {
                bytes: 35,
                lines: 3,
              },
            },
          });
          next();
        },
      );
    });
  });

  describe("map to an index", function () {
    it("get value associated with index", function (next) {
      parse(
        dedent`
          a,b,c
          d,e,f
        `,
        { objname: 1 },
        (err, records) => {
          if (err) return next(err);
          // should.deepEqual(records, {
          should(records).match({
            b: ["a", "b", "c"],
            e: ["d", "e", "f"],
          });
          next();
        },
      );
    });

    it("combined with info", function (next) {
      parse(
        dedent`
          a,b,c
          d,e,f
        `,
        { objname: 1, info: true },
        (err, records) => {
          if (err) return next(err);
          should(records).match({
            b: {
              record: ["a", "b", "c"],
              info: {
                bytes: 6,
                lines: 1,
              },
            },
            e: {
              record: ["d", "e", "f"],
              info: {
                bytes: 11,
                lines: 2,
              },
            },
          });
          next();
        },
      );
    });
  });
});
