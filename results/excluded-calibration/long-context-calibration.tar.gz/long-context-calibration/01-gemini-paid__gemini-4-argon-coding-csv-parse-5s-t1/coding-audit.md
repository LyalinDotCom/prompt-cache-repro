# Independent coding audit

Model: gemini-4-argon. Captured transport attempts: 5; valid raw usage: 5; unknown usage: 0.

Checks: 70 PASS, 0 FAIL, 0 UNKNOWN. Model final text is never used as proof of a patch or passing tests.

| Attempt | HTTP | Input | Reads | Writes | Ordinary | Output | Read/prior input |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 200 | 315391 | 0 | 0 | 315391 | 383 | — |
| 1 | 200 | 323442 | 315392 | 0 | 8050 | 86 | 100.00% |
| 2 | 200 | 324608 | 321393 | 0 | 3215 | 813 | 99.37% |
| 3 | 200 | 325463 | 322559 | 0 | 2904 | 86 | 99.37% |
| 4 | 200 | 326583 | 323414 | 0 | 3169 | 280 | 99.37% |

Input charge estimate: $0.79373380. Output charge estimate: $0.01648000.

Previous-input coverage below 95%: 0/4. Public eligible frontier fully reused: 0/0 (implicit-write frontier unavailable).

Follow-up input charges: $0.16295180; whole-prior-input counterfactual: $0.15127440 (1.0772×). This counterfactual is separate from an eligible-cache guarantee.

## Functional qualification

Baseline exit: 1; final exit: 0; changed source: src/upstream/packages/csv-parse/lib/api/index.js; immutable files checked: 423.


- Each record is one captured fetch invocation; logical model-request retries may produce multiple records and must not be collapsed.
- Missing raw usage stays unknown. Interrupted or unreported charges can exceed known usage costs.
- Gemini has no exposed implicit-write frontier; prior-input coverage is descriptive, not documented eligibility.
- A patch and passing tests establish this task result, not general coding quality.
- A functional qualification is unknown until actual baseline/final command outputs and immutable test hashes are supplied.

Per-attempt raw-counter derivations and check details: [coding-audit.json](coding-audit.json).
