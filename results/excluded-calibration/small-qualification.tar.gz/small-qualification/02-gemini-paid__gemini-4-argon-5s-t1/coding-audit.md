# Independent coding audit

Model: gemini-4-argon. Captured transport attempts: 7; valid raw usage: 7; unknown usage: 0.

Checks: 96 PASS, 0 FAIL, 0 UNKNOWN. Model final text is never used as proof of a patch or passing tests.

| Attempt | HTTP | Input | Reads | Writes | Ordinary | Output | Read/prior input |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 200 | 20993 | 0 | 0 | 20993 | 218 | — |
| 1 | 200 | 25461 | 20994 | 0 | 4467 | 5412 | 100.00% |
| 2 | 200 | 30913 | 25462 | 0 | 5451 | 378 | 100.00% |
| 3 | 200 | 31321 | 28864 | 0 | 2457 | 98 | 93.37% |
| 4 | 200 | 31450 | 29272 | 0 | 2178 | 98 | 93.46% |
| 5 | 200 | 32621 | 29401 | 0 | 3220 | 113 | 93.48% |
| 6 | 200 | 34229 | 30572 | 0 | 3657 | 1145 | 93.72% |

Input charge estimate: $0.10130250. Output charge estimate: $0.07462000.

Previous-input coverage below 95%: 4/6. Public eligible frontier fully reused: 0/0 (implicit-write frontier unavailable).

Follow-up input charges: $0.05931650; whole-prior-input counterfactual: $0.04374790 (1.3559×). This counterfactual is separate from an eligible-cache guarantee.

## Functional qualification

Baseline exit: 1; final exit: 0; changed source: src/csv.mjs, src/dedupe.mjs, src/money.mjs; immutable files checked: 10.


- Each record is one captured fetch invocation; logical model-request retries may produce multiple records and must not be collapsed.
- Missing raw usage stays unknown. Interrupted or unreported charges can exceed known usage costs.
- Gemini has no exposed implicit-write frontier; prior-input coverage is descriptive, not documented eligibility.
- A patch and passing tests establish this task result, not general coding quality.
- A functional qualification is unknown until actual baseline/final command outputs and immutable test hashes are supplied.

Per-attempt raw-counter derivations and check details: [coding-audit.json](coding-audit.json).
