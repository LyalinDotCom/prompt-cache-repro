# Independent coding audit

Model: gpt-6.1-sol. Captured transport attempts: 6; valid raw usage: 6; unknown usage: 0.

Checks: 80 PASS, 0 FAIL, 0 UNKNOWN. Model final text is never used as proof of a patch or passing tests.

| Attempt | HTTP | Input | Reads | Writes | Ordinary | Output | Read/prior input |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 200 | 17874 | 0 | 17871 | 3 | 370 | — |
| 1 | 200 | 27943 | 17871 | 10069 | 3 | 149 | 99.98% |
| 2 | 200 | 33637 | 27940 | 5694 | 3 | 29 | 99.99% |
| 3 | 200 | 37054 | 33634 | 3417 | 3 | 522 | 99.99% |
| 4 | 200 | 37645 | 37051 | 591 | 3 | 92 | 99.99% |
| 5 | 200 | 39814 | 37642 | 2169 | 3 | 259 | 99.99% |

Input charge estimate: $0.11497730. Output charge estimate: $0.01421000.

Previous-input coverage below 95%: 0/5. Public eligible frontier fully reused: 5/5.

Follow-up input charges: $0.07029380; whole-prior-input counterfactual: $0.07026530 (1.0004×). This counterfactual is separate from an eligible-cache guarantee.

## Functional qualification

Baseline exit: 1; final exit: 0; changed source: src/csv.mjs, src/dedupe.mjs, src/money.mjs; immutable files checked: 10.


- Each record is one captured fetch invocation; logical model-request retries may produce multiple records and must not be collapsed.
- Missing raw usage stays unknown. Interrupted or unreported charges can exceed known usage costs.
- Gemini has no exposed implicit-write frontier; prior-input coverage is descriptive, not documented eligibility.
- A patch and passing tests establish this task result, not general coding quality.
- A functional qualification is unknown until actual baseline/final command outputs and immutable test hashes are supplied.

Per-attempt raw-counter derivations and check details: [coding-audit.json](coding-audit.json).
