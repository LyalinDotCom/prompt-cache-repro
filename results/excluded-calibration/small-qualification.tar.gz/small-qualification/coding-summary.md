# Coding cache study

**Completed descriptive report**. 4/4 declared sessions have artifacts. No provider-defect verdict is generated.

Cached reads and preceding input are different public counters. Their ratio does not establish how much input was eligible for caching. Explicit and implicit caching routes differ. Follow-ups within one session are correlated. Costs below are estimates from dated rate cards, not invoices.

| Account / model | Sessions present / planned | Verified repairs | Natural completions | Audited sessions | Actual input range | Valid follow-ups | Reads / prior input |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: |
| gemini-paid / gemini-3.8-flash | 1/1 | 1 | 1 | 1 | 21292–70282 | 11 | 97.07% |
| gemini-paid / gemini-4-argon | 1/1 | 1 | 1 | 1 | 20993–34229 | 6 | 95.26% |
| openai-paid / gpt-6.1-sol | 1/1 | 1 | 1 | 1 | 17874–39814 | 5 | 99.99% |
| anthropic-paid / claude-opus-5-5 | 1/1 | 1 | 1 | 1 | 30190–40694 | 3 | 99.99% |

These input ranges measure occupancy, not advertised context capacity. An experiment is not a 250K-token study unless its actual input counters reach the registered target band. Source preload and organically accumulated history must be interpreted separately.

| Session | Status / stop | Repair verified | Requests | Audit FAIL / UNKNOWN | Final tests pass / fail | Largest prior deficit | Input / output estimate |
| --- | --- | --- | ---: | --- | --- | ---: | --- |
| [gemini-3.8-flash · gemini-paid · coding-ledger · 01-gemini-paid__gemini-3.8-flash-5s-t1](01-gemini-paid__gemini-3.8-flash-5s-t1/coding-report.json) | completed  | true | 12 | 0 / 0 | 44 / 0 | 2520 | $0.112249 / $0.113651 |
| [gemini-4-argon · gemini-paid · coding-ledger · 02-gemini-paid__gemini-4-argon-5s-t1](02-gemini-paid__gemini-4-argon-5s-t1/coding-report.json) | completed  | true | 7 | 0 / 0 | 44 / 0 | 2049 | $0.101303 / $0.074620 |
| [gpt-6.1-sol · openai-paid · coding-ledger · 03-openai-paid__gpt-6.1-sol-5s-t1](03-openai-paid__gpt-6.1-sol-5s-t1/coding-report.json) | completed  | true | 6 | 0 / 0 | 44 / 0 | 3 | $0.114977 / $0.014210 |
| [claude-opus-5-5 · anthropic-paid · coding-ledger · 04-anthropic-paid__claude-opus-5-5-5s-t1](04-anthropic-paid__claude-opus-5-5-5s-t1/coding-report.json) | completed  | true | 4 | 0 / 0 | 44 / 0 | 4 | $0.224134 / $0.058800 |

All attempted sessions remain visible. Cache aggregates above use current independent audits without failed integrity checks. Valid completed requests remain visible when an interrupted final request has unknown telemetry; that final request is excluded. Natural completion and fully passing session audits are reported separately. Failed or missing usage never becomes a cache miss. Functional repair and natural completion are separate outcomes. No confidence interval or provider-wide probability is inferred.

Functional qualification checks the declared fixture-specific CLI result, unchanged acceptance files, and independently executed tests. Only sessions with a fully passing independent audit qualify as verified repairs.
