# Independent coding audit

Model: gemini-3.8-flash. Captured transport attempts: 12; valid raw usage: 12; unknown usage: 0.

Checks: 161 PASS, 0 FAIL, 0 UNKNOWN. Model final text is never used as proof of a patch or passing tests.

| Attempt | HTTP | Input | Reads | Writes | Ordinary | Output | Read/prior input |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 200 | 21292 | 0 | 0 | 21292 | 413 | — |
| 1 | 200 | 26083 | 21360 | 0 | 4723 | 27824 | 100.32% |
| 2 | 200 | 61006 | 29486 | 0 | 31520 | 95 | 113.05% |
| 3 | 200 | 61129 | 58660 | 0 | 2469 | 435 | 96.15% |
| 4 | 200 | 61591 | 58742 | 0 | 2849 | 48 | 96.10% |
| 5 | 200 | 62710 | 59128 | 0 | 3582 | 177 | 96.00% |
| 6 | 200 | 64390 | 60190 | 0 | 4200 | 328 | 95.98% |
| 7 | 200 | 65788 | 61916 | 0 | 3872 | 34 | 96.16% |
| 8 | 200 | 66901 | 63355 | 0 | 3546 | 107 | 96.30% |
| 9 | 200 | 68271 | 64448 | 0 | 3823 | 43 | 96.33% |
| 10 | 200 | 68985 | 65897 | 0 | 3088 | 42 | 96.52% |
| 11 | 200 | 70282 | 66554 | 0 | 3728 | 761 | 96.48% |

Input charge estimate: $0.11224920. Output charge estimate: $0.11365125.

Previous-input coverage below 95%: 0/11. Public eligible frontier fully reused: 0/0 (implicit-write frontier unavailable).

Follow-up input charges: $0.09628020; whole-prior-input counterfactual: $0.08385345 (1.1482×). This counterfactual is separate from an eligible-cache guarantee.

## Functional qualification

Baseline exit: 1; final exit: 0; changed source: src/csv.mjs, src/dedupe.mjs, src/money.mjs; immutable files checked: 10.


- Each record is one captured fetch invocation; logical model-request retries may produce multiple records and must not be collapsed.
- Missing raw usage stays unknown. Interrupted or unreported charges can exceed known usage costs.
- Gemini has no exposed implicit-write frontier; prior-input coverage is descriptive, not documented eligibility.
- A patch and passing tests establish this task result, not general coding quality.
- A functional qualification is unknown until actual baseline/final command outputs and immutable test hashes are supplied.

Per-attempt raw-counter derivations and check details: [coding-audit.json](coding-audit.json).
