# Independent coding audit

Model: claude-opus-5-5. Captured transport attempts: 3; valid raw usage: 3; unknown usage: 0.

Checks: 46 PASS, 0 FAIL, 0 UNKNOWN. Model final text is never used as proof of a patch or passing tests.

| Attempt | HTTP | Input | Reads | Writes | Ordinary | Output | Read/prior input |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 200 | 377261 | 0 | 377257 | 4 | 139 | — |
| 1 | 200 | 383381 | 377257 | 6122 | 2 | 420 | 100.00% |
| 2 | 200 | 385295 | 383379 | 1914 | 2 | 551 | 100.00% |

Input charge estimate: $2.07862420. Output charge estimate: $0.02220000.

Previous-input coverage below 95%: 0/2. Public eligible frontier fully reused: 2/2.

Follow-up input charges: $0.19232320; whole-prior-input counterfactual: $0.19229840 (1.0001×). This counterfactual is separate from an eligible-cache guarantee.

## Functional qualification

Baseline exit: 1; final exit: 0; changed source: src/upstream/packages/csv-stringify/lib/api/index.js; immutable files checked: 425.


- Each record is one captured fetch invocation; logical model-request retries may produce multiple records and must not be collapsed.
- Missing raw usage stays unknown. Interrupted or unreported charges can exceed known usage costs.
- Gemini has no exposed implicit-write frontier; prior-input coverage is descriptive, not documented eligibility.
- A patch and passing tests establish this task result, not general coding quality.
- A functional qualification is unknown until actual baseline/final command outputs and immutable test hashes are supplied.

Per-attempt raw-counter derivations and check details: [coding-audit.json](coding-audit.json).
